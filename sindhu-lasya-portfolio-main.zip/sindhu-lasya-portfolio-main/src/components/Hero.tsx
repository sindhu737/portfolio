import { useEffect, useRef } from "react";
import heroBg from "@/assets/hero-bg.jpg";

const Hero = () => {
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("animate-fade-in");
          }
        });
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section
      id="about"
      ref={sectionRef}
      className="min-h-screen flex items-center justify-center relative overflow-hidden pt-20"
      style={{
        backgroundImage: `url(${heroBg})`,
        backgroundSize: "cover",
        backgroundPosition: "center",
      }}
    >
      <div className="absolute inset-0 bg-background/80 backdrop-blur-sm" />
      
      <div className="container mx-auto px-6 relative z-10">
        <div className="max-w-4xl mx-auto text-center">
          <div className="mb-8 opacity-0 animate-fade-in" style={{ animationDelay: "0.2s" }}>
            <h1 className="font-serif text-5xl md:text-7xl font-bold mb-4 text-foreground">
              Tulluri Sindhu Lasya
            </h1>
            <p className="text-xl md:text-2xl text-muted-foreground font-medium">
              Computer Science & Engineering
            </p>
            <p className="text-lg md:text-xl text-muted-foreground">
              IIT Indore • Roll: 240001074
            </p>
          </div>

          <div className="opacity-0 animate-fade-in" style={{ animationDelay: "0.4s" }}>
            <div className="bg-card/90 backdrop-blur-sm rounded-2xl p-8 shadow-soft hover:shadow-hover transition-smooth">
              <h2 className="font-serif text-2xl md:text-3xl font-semibold mb-4 text-foreground">
                About Me
              </h2>
              <p className="text-base md:text-lg text-muted-foreground leading-relaxed mb-4">
                I'm a passionate Computer Science student at IIT Indore, driven by curiosity and creativity. 
                My journey in technology is fueled by a love for AI/ML and web development, where I enjoy 
                building solutions that make a difference.
              </p>
              <p className="text-base md:text-lg text-muted-foreground leading-relaxed">
                Beyond coding, I express myself through dance and singing, believing that creativity in 
                art enhances innovation in technology. I'm always eager to learn, collaborate, and take 
                on new challenges that push my boundaries.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
