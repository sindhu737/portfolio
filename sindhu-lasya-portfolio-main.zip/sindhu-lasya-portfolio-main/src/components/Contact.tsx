import { useEffect, useRef } from "react";
import { Mail, Github, Linkedin, Heart } from "lucide-react";
import { Button } from "@/components/ui/button";

const Contact = () => {
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("animate-fade-in");
          }
        });
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section id="contact" ref={sectionRef} className="py-20 bg-muted/30">
      <div className="container mx-auto px-6">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12 opacity-0">
            <h2 className="font-serif text-4xl md:text-5xl font-bold mb-4 text-foreground">
              Let's Connect
            </h2>
            <p className="text-lg text-muted-foreground">
              I'm always open to discussing new projects, opportunities, or just having a chat
            </p>
          </div>

          <div className="bg-card rounded-2xl p-8 md:p-12 shadow-soft text-center opacity-0" style={{ animationDelay: "0.2s" }}>
            <div className="inline-flex items-center justify-center w-16 h-16 bg-primary rounded-full mb-6 animate-float">
              <Mail className="w-8 h-8 text-primary-foreground" />
            </div>
            
            <h3 className="font-serif text-2xl font-semibold mb-4 text-foreground">
              Get In Touch
            </h3>
            
            <a
              href="mailto:sindhulasyatulluri@gmail.com"
              className="text-xl text-primary hover:text-primary-dark transition-smooth font-medium mb-8 inline-block"
            >
              sindhulasyatulluri@gmail.com
            </a>

            <div className="flex justify-center gap-4 mt-8">
              <Button
                variant="outline"
                size="icon"
                className="rounded-full w-12 h-12 border-2 hover:bg-primary hover:text-primary-foreground hover:border-primary transition-smooth"
                asChild
              >
                <a href="mailto:sindhulasyatulluri@gmail.com" aria-label="Email">
                  <Mail className="w-5 h-5" />
                </a>
              </Button>
              <Button
                variant="outline"
                size="icon"
                className="rounded-full w-12 h-12 border-2 hover:bg-primary hover:text-primary-foreground hover:border-primary transition-smooth"
                asChild
              >
                <a href="#" aria-label="GitHub" target="_blank" rel="noopener noreferrer">
                  <Github className="w-5 h-5" />
                </a>
              </Button>
              <Button
                variant="outline"
                size="icon"
                className="rounded-full w-12 h-12 border-2 hover:bg-primary hover:text-primary-foreground hover:border-primary transition-smooth"
                asChild
              >
                <a href="#" aria-label="LinkedIn" target="_blank" rel="noopener noreferrer">
                  <Linkedin className="w-5 h-5" />
                </a>
              </Button>
            </div>
          </div>

          <div className="text-center mt-12 opacity-0" style={{ animationDelay: "0.4s" }}>
            <p className="text-muted-foreground flex items-center justify-center gap-2">
              Made with <Heart className="w-4 h-4 text-primary fill-primary animate-pulse" /> by Sindhu Lasya
            </p>
            <p className="text-muted-foreground mt-4">
              For inquiries, reach me at: <a href="mailto:sindhulasyatulluri@gmail.com" className="text-primary hover:underline">sindhulasyatulluri@gmail.com</a>
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;
