import { useEffect, useRef } from "react";
import { ExternalLink, Users, ShoppingCart, Layout } from "lucide-react";
import { Button } from "@/components/ui/button";

const Projects = () => {
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const cards = entry.target.querySelectorAll(".project-card");
            cards.forEach((card, index) => {
              setTimeout(() => {
                card.classList.add("animate-fade-in");
              }, index * 150);
            });
          }
        });
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const projects = [
    {
      icon: Users,
      title: "IITISoC Drone Footage Project",
      description:
        "Led a collaborative team to analyze drone footage using advanced AI/ML techniques. Implemented computer vision algorithms for object detection and tracking, resulting in improved data analysis capabilities.",
      technologies: ["AI/ML", "Computer Vision", "Python", "Team Leadership"],
      gradient: "gradient-primary",
    },
    {
      icon: ShoppingCart,
      title: "Supermarket Management System",
      description:
        "Developed a comprehensive web-based management system for supermarket operations. Features include delivery tracking, supplier data management, and an intuitive interface for inventory control.",
      technologies: ["Web Development", "JavaScript", "Database Management", "UI/UX"],
      gradient: "gradient-accent",
    },
    {
      icon: Layout,
      title: "Personal Portfolio Website",
      description:
        "Designed and built this interactive single-page portfolio using modern web technologies. Features smooth animations, responsive design, and an elegant pastel theme to showcase my work and achievements.",
      technologies: ["HTML5", "CSS3", "JavaScript", "Responsive Design"],
      gradient: "gradient-primary",
    },
  ];

  return (
    <section id="projects" ref={sectionRef} className="py-20 bg-background">
      <div className="container mx-auto px-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="font-serif text-4xl md:text-5xl font-bold mb-4 text-foreground">
              Featured Projects
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Showcasing innovation through AI, web development, and creative problem-solving
            </p>
          </div>

          <div className="space-y-8">
            {projects.map((project, index) => {
              const Icon = project.icon;
              return (
                <div
                  key={index}
                  className="project-card opacity-0 bg-card rounded-2xl p-8 shadow-soft hover:shadow-hover transition-smooth group"
                >
                  <div className="flex flex-col md:flex-row gap-6">
                    <div className={`${project.gradient} p-4 rounded-xl self-start group-hover:scale-110 transition-smooth`}>
                      <Icon className="w-8 h-8 text-white" />
                    </div>
                    
                    <div className="flex-1">
                      <h3 className="font-serif text-2xl md:text-3xl font-semibold mb-3 text-foreground">
                        {project.title}
                      </h3>
                      <p className="text-muted-foreground mb-4 leading-relaxed">
                        {project.description}
                      </p>
                      <div className="flex flex-wrap gap-2">
                        {project.technologies.map((tech, techIndex) => (
                          <span
                            key={techIndex}
                            className="px-3 py-1 bg-accent-light text-accent-foreground rounded-full text-sm font-medium"
                          >
                            {tech}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Projects;
