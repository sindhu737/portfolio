import { useEffect, useState } from "react";

interface WelcomeScreenProps {
  onComplete: () => void;
}

const WelcomeScreen = ({ onComplete }: WelcomeScreenProps) => {
  const [isVisible, setIsVisible] = useState(true);

  useEffect(() => {
    // After 3 seconds, start fade out
    const timer = setTimeout(() => {
      setIsVisible(false);
      // After fade out completes, call onComplete
      setTimeout(onComplete, 600);
    }, 3000);

    return () => clearTimeout(timer);
  }, [onComplete]);

  return (
    <div
      className={`fixed inset-0 z-50 flex items-center justify-center bg-background transition-opacity duration-600 ${
        isVisible ? "opacity-100" : "opacity-0"
      }`}
    >
      <h1 className="text-5xl md:text-7xl font-serif text-primary animate-slide-up">
        Welcome, this is Sindhu
      </h1>
    </div>
  );
};

export default WelcomeScreen;
