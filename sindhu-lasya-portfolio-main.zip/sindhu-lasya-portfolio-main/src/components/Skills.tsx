import { useEffect, useRef } from "react";
import { Code2, Palette, Users, Brain } from "lucide-react";

const Skills = () => {
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const cards = entry.target.querySelectorAll(".skill-card");
            cards.forEach((card, index) => {
              setTimeout(() => {
                card.classList.add("animate-fade-in");
              }, index * 100);
            });
          }
        });
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const skillCategories = [
    {
      icon: Code2,
      title: "Programming",
      skills: ["Python", "C++", "JavaScript", "HTML", "CSS"],
      gradient: "gradient-primary",
    },
    {
      icon: Brain,
      title: "Technologies",
      skills: ["AI/ML", "Web Development", "Data Analysis", "Algorithm Design"],
      gradient: "gradient-accent",
    },
    {
      icon: Palette,
      title: "Creative",
      skills: ["Dance", "Singing", "UI/UX Awareness", "Content Creation"],
      gradient: "gradient-primary",
    },
    {
      icon: Users,
      title: "Soft Skills",
      skills: ["Leadership", "Team Collaboration", "Problem Solving", "Communication"],
      gradient: "gradient-accent",
    },
  ];

  return (
    <section id="skills" ref={sectionRef} className="py-20 bg-muted/30">
      <div className="container mx-auto px-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="font-serif text-4xl md:text-5xl font-bold mb-4 text-foreground">
              Skills & Expertise
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              A blend of technical proficiency and creative passion
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            {skillCategories.map((category, index) => {
              const Icon = category.icon;
              return (
                <div
                  key={index}
                  className="skill-card opacity-0 bg-card rounded-2xl p-6 shadow-soft hover:shadow-hover transition-smooth group"
                >
                  <div className="flex items-start gap-4 mb-4">
                    <div className={`${category.gradient} p-3 rounded-xl group-hover:scale-110 transition-smooth`}>
                      <Icon className="w-6 h-6 text-white" />
                    </div>
                    <h3 className="font-serif text-2xl font-semibold text-foreground">
                      {category.title}
                    </h3>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {category.skills.map((skill, skillIndex) => (
                      <span
                        key={skillIndex}
                        className="px-4 py-2 bg-muted/50 rounded-full text-sm font-medium text-foreground hover:bg-primary hover:text-primary-foreground transition-smooth"
                      >
                        {skill}
                      </span>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Skills;
